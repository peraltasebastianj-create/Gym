# Galeria de ejercicios listo para ensamblar en el html del index

A Pen created on CodePen.

Original URL: [https://codepen.io/S-P-the-bashful/pen/EaVoaRa](https://codepen.io/S-P-the-bashful/pen/EaVoaRa).

